Esx_lscustomsV3


This is a lscustoms script i came across on a random forum i looked through it and optimised it and added support for esx. and stated adding support for bennys customs cars.


You should obviously be running esx if you try using this version.


Known issues:

Some mods are missing mostly bennys customs modifications.
I will try to compare this version with the other esx ls custom and see what mods are missing.
This is a long term goal. It will take time as i have other script to work on and my priority is to launch my server soon.
Feel free to make pull request if you add missing mods. Thanks!




Credits:

I give credits to the person/people who originally made this script. i do not take any rights to the base code as i have just added ontop of it and made small changes to the base code to optimise it.
